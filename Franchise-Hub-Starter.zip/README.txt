FRANCHISE HUB
A starter website for Madden + NBA 2K franchise communities.

Open index.html in a browser to preview it.

Next production steps:
1. Add user accounts/authentication.
2. Connect a database for real leagues, users, standings and applications.
3. Add Discord OAuth/invite management.
4. Add commissioner dashboards and moderation.
5. Deploy to a public domain.
